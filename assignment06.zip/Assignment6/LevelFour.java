package Assignment6;

public class LevelFour {
	private int numval;
	public LevelFour(int anumval){
		numval = anumval;
	}
	public double measure(){
		double ret = numval;
		return ret;
	}
	public double value(){
		double ret = numval;
		return ret;
	}
}
