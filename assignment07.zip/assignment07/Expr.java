package assignment07;
/*
 * abstract class and method so the add, mul, neg, and num class
 * can override the empty method
 */
public abstract class Expr {
	public abstract int eval();
}
