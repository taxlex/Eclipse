package assignment07;

public class Frugal implements Play {
	
	@Override
	public int takeTurn(int currentState) {
		return 1;
	}

}