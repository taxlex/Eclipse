package project;

public interface HaltCallback {
	public void halt();
}
