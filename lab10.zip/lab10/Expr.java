package lab10;

public abstract class Expr {
    public abstract int eval();
    public abstract String toString();
}