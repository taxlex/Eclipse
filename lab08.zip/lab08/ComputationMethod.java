package lab08;

import java.util.List;

public abstract class ComputationMethod {
	public abstract int compute(List<Card> cards);
}
